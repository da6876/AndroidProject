package oma.soc.bd.com.omanmotorassistance;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import oma.soc.bd.com.omanmotorassistance.welcome.WelcomePage;

public class FastPage extends AppCompatActivity {
    ImageView iv_image;
    TextView tv_welcome,tv_app_name;
    Handler handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fast_page);

        iv_image=findViewById(R.id.iv_image);
        tv_welcome=findViewById(R.id.tv_welcome);
        tv_app_name=findViewById(R.id.tv_app_name);

        Animation animation=AnimationUtils.loadAnimation(FastPage.this,R.anim.fadein);
        iv_image.startAnimation(animation);

        handler=new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent=new Intent(FastPage.this, WelcomePage.class);
                startActivity(intent);
                finish();
            }
        },3000);
    }
}
